/**
* @type {import('vite').UserConfig}
*/
export default {
    base: "https://KubaGlegola.github.io/",
    css: {
        devSourcemap: true,
    },
}